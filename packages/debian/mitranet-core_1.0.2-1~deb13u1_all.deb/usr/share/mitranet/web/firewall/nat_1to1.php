﻿<?php
/*
 * firewall_nat_1to1.php - MitraNet 1:1 NAT Management
 * Adapted from pfSense firewall_nat_1to1.php
 * Strictly communicates via REST API -> MitraNet Native nftables Engine.
 */

$pgtitle = array(gettext("Firewall"), gettext("NAT"), gettext("1:1"));
$selected_menu = "firewall";
require_once(__DIR__ . '/../includes/head.inc');

$msg = '';
$err = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $rid = trim($_POST['id'] ?? '');
        $iface = $_POST['interface'] ?? 'enp0s3';
        $ext_ip = trim($_POST['ext_ip'] ?? '');
        $int_ip = trim($_POST['int_ip'] ?? '');
        $descr = trim($_POST['descr'] ?? '');
        $prio = (int)($_POST['priority'] ?? 100);

        if (!empty($rid) && !empty($ext_ip) && !empty($int_ip)) {
            $res = MitraNetApi::request('/firewall/nat/add', 'POST', [
                'id' => $rid,
                'nat_type' => 'one_to_one',
                'interface' => $iface,
                'protocol' => 'any',
                'dst_ip' => $ext_ip,
                'target_ip' => $int_ip,
                'priority' => $prio,
                'description' => $descr
            ]);
            if ($res['status'] === 200) {
                $msg = "1:1 NAT Rule '$rid' added to candidate configuration";
            } else {
                $err = $res['data']['error'] ?? 'Failed to add 1:1 NAT rule';
            }
        } else {
            $err = 'Rule ID, External IP, and Internal IP are required';
        }
    } elseif ($action === 'delete') {
        $rid = trim($_POST['id'] ?? '');
        if (!empty($rid)) {
            $res = MitraNetApi::request('/firewall/nat/delete', 'POST', ['id' => $rid]);
            if ($res['status'] === 200) {
                $msg = "1:1 NAT Rule '$rid' deleted from candidate configuration";
            } else {
                $err = $res['data']['error'] ?? 'Failed to delete NAT rule';
            }
        }
    } elseif ($action === 'apply') {
        $res = MitraNetApi::request('/firewall/apply', 'POST', []);
        if ($res['status'] === 200) {
            $msg = "1:1 NAT rules applied and committed to Linux kernel nftables successfully";
        } else {
            $err = $res['data']['error'] ?? 'Failed to apply NAT rules';
        }
    }
}

$fw = MitraNetApi::getFirewall();
$running_nat = array_filter($fw['config']['nat_rules'] ?? [], fn($r) => ($r['nat_type'] ?? '') === 'one_to_one');
$candidate_nat = array_filter($fw['candidate']['nat_rules'] ?? [], fn($r) => ($r['nat_type'] ?? '') === 'one_to_one');
$ifaces = MitraNetApi::getInterfaces();
?>

$tab_array = array();
$tab_array[] = array(gettext("Port Forward"), false, "firewall_nat.php");
$tab_array[] = array(gettext("1:1"), true, "firewall_nat_1to1.php");
$tab_array[] = array(gettext("Outbound"), false, "firewall_nat_out.php");
$tab_array[] = array(gettext("NPt"), false, "firewall_nat_npt.php");
display_top_tabs($tab_array);

if (!empty($msg)) {
    print_info_box($msg, "success");
}
if (!empty($err)) {
    print_info_box($err, "danger");
}
?>

<!-- Running NAT Ruleset -->
<div class="panel panel-default">
	<div class="panel-heading"><h3 class="panel-title"><i class="fa fa-list"></i> Active / Running 1:1 NAT Rules</h3></div>
	<div class="panel-body">
		<table class="table table-striped table-hover">
			<thead>
				<tr>
					<th>ID</th>
					<th>Interface</th>
					<th>External IP</th>
					<th>Internal IP</th>
					<th>Description</th>
				</tr>
			</thead>
			<tbody>
				<?php if (empty($running_nat)): ?>
					<tr><td colspan="5" class="text-center text-muted">No custom 1:1 NAT rules defined in running ruleset</td></tr>
				<?php else: foreach ($running_nat as $nr): ?>
					<tr>
						<td><strong><?=htmlspecialchars($nr['id'])?></strong></td>
						<td><?=htmlspecialchars($nr['interface'])?></td>
						<td><code><?=htmlspecialchars($nr['dst_ip'])?></code></td>
						<td><code><?=htmlspecialchars($nr['target_ip'])?></code></td>
						<td><?=htmlspecialchars($nr['description'] ?? '')?></td>
					</tr>
				<?php endforeach; endif; ?>
			</tbody>
		</table>
	</div>
</div>

<!-- Candidate NAT Ruleset -->
<div class="panel panel-info">
	<div class="panel-heading">
		<div class="pull-right">
			<form method="post" class="form-inline-action">
				<input type="hidden" name="action" value="apply">
				<button type="submit" class="btn btn-sm btn-success"><i class="fa fa-check"></i> Apply Candidate Changes</button>
			</form>
		</div>
		<h3 class="panel-title"><i class="fa fa-edit"></i> Candidate 1:1 Rules</h3>
	</div>
	<div class="panel-body">
		<table class="table table-striped">
			<thead>
				<tr>
					<th>Rule ID</th>
					<th>Interface</th>
					<th>External IP</th>
					<th>Internal IP</th>
					<th>Description</th>
					<th>Action</th>
				</tr>
			</thead>
			<tbody>
				<?php if (empty($candidate_nat)): ?>
					<tr><td colspan="6" class="text-center text-muted">Candidate 1:1 ruleset matches running ruleset</td></tr>
				<?php else: foreach ($candidate_nat as $nr): ?>
					<tr>
						<td><?=htmlspecialchars($nr['id'])?></td>
						<td><?=htmlspecialchars($nr['interface'])?></td>
						<td><code><?=htmlspecialchars($nr['dst_ip'])?></code></td>
						<td><code><?=htmlspecialchars($nr['target_ip'])?></code></td>
						<td><?=htmlspecialchars($nr['description'] ?? '')?></td>
						<td>
							<form method="post" class="form-inline-action">
								<input type="hidden" name="action" value="delete">
								<input type="hidden" name="id" value="<?=htmlspecialchars($nr['id'])?>">
								<button type="submit" class="btn btn-xs btn-danger"><i class="fa fa-trash"></i></button>
							</form>
						</td>
					</tr>
				<?php endforeach; endif; ?>
			</tbody>
		</table>

		<hr>
		<h4>Add 1:1 NAT Rule</h4>
		<form method="post" class="form-inline">
			<input type="hidden" name="action" value="add">
			<div class="form-group mb-10">
				<label>Rule ID</label><br>
				<input type="text" name="id" class="form-control input-sm" placeholder="e.g. nat1to1_server" required>
			</div>
			<div class="form-group mb-10">
				<label>Interface</label><br>
				<select name="interface" class="form-control input-sm">
					<?php foreach ($ifaces as $if): ?>
						<option value="<?=htmlspecialchars($if['name'])?>"><?=htmlspecialchars($if['name'])?></option>
					<?php endforeach; ?>
				</select>
			</div>
			<div class="form-group mb-10">
				<label>External IP</label><br>
				<input type="text" name="ext_ip" class="form-control input-sm" placeholder="e.g. 10.10.66.50" required>
			</div>
			<div class="form-group mb-10">
				<label>Internal IP</label><br>
				<input type="text" name="int_ip" class="form-control input-sm" placeholder="e.g. 192.168.56.150" required>
			</div>
			<div class="form-group mb-10">
				<label>Description</label><br>
				<input type="text" name="descr" class="form-control input-sm" placeholder="Description">
			</div>
			<div class="form-group mb-10">
				<label>&nbsp;</label><br>
				<button type="submit" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Add 1:1 Rule</button>
			</div>
		</form>
	</div>
</div>

<?php require_once(__DIR__ . '/../includes/foot.inc'); ?>
